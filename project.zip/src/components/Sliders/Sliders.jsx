import React from "react";
import Slider from "react-slick";
import "./sliders.scss";

const Sliders = () => {
  const settings = {
    dots: false,
    infinite: true,
    speed: 800,
    slidesToShow: 3,
    slidesToScroll: 2,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <div className="container-slider">
      <div className="slider-parent-div">
      <Slider {...settings}>
        <div className="div-carousel-components">
          <img className="images-of-carousel" src="img/pubg.jpg" alt="" />
          <div>
            <div className="parent-of-card-compenents-carousel">
              <div className="second-parent-of-card-compenents-carousel">
                <div>
                  <h3 className="title-of-card-components-carousel">
                    4 Groups
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    32 Players
                  </h2>
                </div>
                <div className="third-parent-of-card-compenents-carousel">
                  <h3 className="title-of-card-components-carousel">
                    Prize Pool
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    5000$
                  </h2>
                </div>
              </div>
              <h3 className="title-of-card-components-carousel">
                Mar.26.2020 - 04:13 Pm
              </h3>
            </div>
          </div>
        </div>
        <div className="div-carousel-components">
          <img className="images-of-carousel" src="img/cs.jpg" alt="" />
          <div>
            <div className="parent-of-card-compenents-carousel">
              <div className="second-parent-of-card-compenents-carousel">
                <div>
                  <h3 className="title-of-card-components-carousel">
                    4 Groups
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    32 Players
                  </h2>
                </div>
                <div className="third-parent-of-card-compenents-carousel">
                  <h3 className="title-of-card-components-carousel">
                    Prize Pool
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    5000$
                  </h2>
                </div>
              </div>
              <h3 className="title-of-card-components-carousel">
                Mar.26.2020 - 04:13 Pm
              </h3>
            </div>
          </div>
        </div>
        <div className="div-carousel-components">
          <img className="images-of-carousel" src="img/fortnite.jpg" alt="" />
          <div>
            <div className="parent-of-card-compenents-carousel">
              <div className="second-parent-of-card-compenents-carousel">
                <div>
                  <h3 className="title-of-card-components-carousel">
                    4 Groups
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    32 Players
                  </h2>
                </div>
                <div className="third-parent-of-card-compenents-carousel">
                  <h3 className="title-of-card-components-carousel">
                    Prize Pool
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    5000$
                  </h2>
                </div>
              </div>
              <h3 className="title-of-card-components-carousel">
                Mar.26.2020 - 04:13 Pm
              </h3>
            </div>
          </div>
        </div>
        <div className="div-carousel-components">
          <img className="images-of-carousel" src="img/dota.jpg" alt="" />
          <div>
            <div className="parent-of-card-compenents-carousel">
              <div className="second-parent-of-card-compenents-carousel">
                <div>
                  <h3 className="title-of-card-components-carousel">
                    4 Groups
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    32 Players
                  </h2>
                </div>
                <div className="third-parent-of-card-compenents-carousel">
                  <h3 className="title-of-card-components-carousel">
                    Prize Pool
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    5000$
                  </h2>
                </div>
              </div>
              <h3 className="title-of-card-components-carousel">
                Mar.26.2020 - 04:13 Pm
              </h3>
            </div>
          </div>
        </div>
        <div className="div-carousel-components">
          <img className="images-of-carousel" src="img/csgo.jpg" alt="" />
          <div>
            <div className="parent-of-card-compenents-carousel">
              <div className="second-parent-of-card-compenents-carousel">
                <div>
                  <h3 className="title-of-card-components-carousel">
                    4 Groups
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    32 Players
                  </h2>
                </div>
                <div className="third-parent-of-card-compenents-carousel">
                  <h3 className="title-of-card-components-carousel">
                    Prize Pool
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    5000$
                  </h2>
                </div>
              </div>
              <h3 className="title-of-card-components-carousel">
                Mar.26.2020 - 04:13 Pm
              </h3>
            </div>
          </div>
        </div>
        <div className="div-carousel-components">
          <img className="images-of-carousel" src="img/fortnite1.jpg" alt="" />
          <div>
            <div className="parent-of-card-compenents-carousel">
              <div className="second-parent-of-card-compenents-carousel">
                <div>
                  <h3 className="title-of-card-components-carousel">
                    4 Groups
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    32 Players
                  </h2>
                </div>
                <div className="third-parent-of-card-compenents-carousel">
                  <h3 className="title-of-card-components-carousel">
                    Prize Pool
                  </h3>
                  <h2 className="subtitle-of-card-components-carousel">
                    5000$
                  </h2>
                </div>
              </div>
              <h3 className="title-of-card-components-carousel">
                Mar.26.2020 - 04:13 Pm
              </h3>
            </div>
          </div>
        </div>
      </Slider>
      </div>
    </div>
  );
};

export default Sliders;
