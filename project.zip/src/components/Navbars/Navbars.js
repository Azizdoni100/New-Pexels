import React, { useState, useEffect } from "react";
import "./navbars.scss";
import { Link } from "react-router-dom";

const Navbars = () => {
  const [openNav, setOpenNav] = useState(false);
  const [navSize, setnavSize] = useState("50px");
  const [navColor, setnavColor] = useState("transparent");
  const listenScrollEvent = () => {
    window.scrollY > 10 ? setnavColor("#0e0e0e") : setnavColor("transparent");
    window.scrollY > 10 ? setnavSize("65px") : setnavSize("65px");
  };
  useEffect(() => {
    window.addEventListener("scroll", listenScrollEvent);
    return () => {
      window.removeEventListener("scroll", listenScrollEvent);
    };
  }, []);

  return (
    <div
      className="parent-of-nav section-nav"
      style={{
        backgroundColor: navColor,
        height: navSize,
        transition: "all 1s",
      }}
    >
      <div className="container-nav">
        <nav>
          <img className="logo" src="img/logo.png" alt="" />
          <ul className={`${openNav ? "showNavbar" : ""}`}>
             <li>
              <Link className="a-navbar" to="/admin">Admin</Link>
            </li>
            <li>
              <Link className="a-navbar" to="/">Home</Link>
            </li>
            <li>
              <Link className="a-navbar" to="/blog">Blog</Link>
            </li>
            <li>
              <Link className="a-navbar" to="/gallery">Gallery</Link>
            </li>
            <li>
              <div className="dropdown">
                <a href="#" className="a-navbar">Pages</a>
                <div className="dropdown-content">
                  <Link to="/pageerror" className="a-href-nav">404 Page</Link>
                  <Link to="/about" className="a-href-nav">About us</Link>
                  <Link to="/coming" className="a-href-nav">Coming Soon</Link>
                  <Link to="/clan" className="a-href-nav">Our clan</Link>
                </div>
              </div>
            </li>

            <li>
              <Link className="a-navbar" to="/videoland">Portfolio</Link>
            </li>
            <li>
              <Link className="a-navbar" to="/contact">Contacts</Link>
            </li>

            <li>
              <div className="dropdown">
                <a href="#" className="a-navbar">Elements</a>
                <div className="dropdown-content">
                  <Link to="/music" className="a-href-nav">Card Gallery</Link>
                  <Link to="/music" className="a-href-nav">Cards</Link>
                  <Link to="/music" className="a-href-nav">Player</Link>
                </div>
              </div>
            </li>
            <li>
              <Link className="al-navbar nav-button-navbar navbar-lines" to="/login"><button className="btn-log-out">Login</button></Link>
            </li>
            <h2 className="line-nav">-</h2>
            <li>
              <Link className="al-navbar nav-button-navbar navbar-line" to="/register"><button className="btn-log-out">Register</button></Link>
            </li>
          </ul>
          <input
            onClick={() => setOpenNav(!openNav)}
            className="btn-navbar"
            id="menu__toggle"
            type="checkbox"
          />
          <label className="menu__btn btn-navbar" for="menu__toggle">
            <span></span>
          </label>
        </nav>
      </div>
    </div>
  );
};

export default Navbars;
