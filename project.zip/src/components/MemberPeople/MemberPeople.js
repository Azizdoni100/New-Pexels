import React from 'react'

const MemberPeople = () => {
    return (
        <div>
 
         </div>
    )
}

export default MemberPeople
