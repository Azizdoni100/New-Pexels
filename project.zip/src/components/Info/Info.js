import React from 'react';
import { useParams } from 'react-router-dom'
import data from '../../data';
import "./Info.scss"

const Info = () => {
    const params = useParams()
    console.log(params.bleble)
    const person = data.find((el) => {
        return el.id == params.bleble
    })
  
    return (
    <div className='container'>
      <div className='parent-blog-parent'>
      <div className='parent-info'>
            <img className='image-section-info' src={person.img} alt=""/>
            <div className='parent-second-section-info'>
              <h3 className='data-title'>{person.data}</h3>
              <button className='btn-title-info'>#{person.category}</button>
            </div>
            <h2 className=' -of-info'>{person.title}</h2>
            <p className='subtitle-of-info'>{person.subtitle}</p>
            <p className='text-of-info'>{person.text}</p>
            <h2 className='titled-of-info'>{person.titled}</h2>
            <p className='text-of-info'>{person.subtext}</p>
        </div>
        <div className='parent-about-info'>
           <h2 className='h2-info-blog'>About me</h2>
           <img className='img-reklama' src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img42.jpg" alt=''/>
            <p className="subtitle-reklama">Through our best techniques and bespoke growth plans we assess digital problems and put in place strategies that lead to commercial success.</p>       
            <h2 className='title-info-blog'>Categories</h2>
        </div>
      </div>
    </div>
  )
};

export default Info;
