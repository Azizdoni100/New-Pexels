import React from 'react'
import Slidebar from '../../Slidebar/Slidebar'

const Products = () => {
    return (
        <div className='container'>
            <h1 className='user-title'>There will be Products</h1>
        </div>
    )
}

export default Products
