import React from 'react'
import "./users.scss"

const Users = () => {
    return (
        <div className='container'>
            <h1 className='user-title'>There will be the users</h1>
        </div>
    )
}

export default Users
