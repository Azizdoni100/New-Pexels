import React from 'react'

const Homes = () => {
    return (
        <div>
            <h1>hello</h1>
        </div>
    )
}

export default Homes
