import React from 'react';
import "./pageerror.scss"
import {motion} from "framer-motion"

const PageError = () => {
  return (
    <motion.div layout animate={{opacity: 1}} initial={{opacity: 0}} exit={{opacity: 0}}>
    <div className='bg-error'>
      <div className='container'>
        <div className='parent-error'>
          <p className='subtitle-error'>#oooops</p>
          <h1 className='title-error'>404 Error</h1>
            <h2 className='text-error'>You are on a non existing page!</h2>
          <button className='btn-first-carousel-section'>Get Back Home</button>
        </div>
      </div>
    </div>
    </motion.div>
  )
};

export default PageError;
