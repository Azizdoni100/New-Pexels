import React from 'react'
import "./music.scss"

const Music = () => {
  return (
<div className='container'>
    <div class="l-container">
      <div className="b-game-card">
        <div className="b-game-card__cover fourth-s" ></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover third-s"></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover second-s"></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover first-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover twelveth-s" ></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover fifth-s"></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover six-s"></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover seventh-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover eight-s" ></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover nineth-s"></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover tenth-s"></div>
      </div>
      <div className="b-game-card">
        <div className="b-game-card__cover eleventh-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover fifty-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover thirty-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover fourty-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover sixty-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover b1-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover b2-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover b3-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover b4-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover b5-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover b6-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover b7-s"></div>
        </div>
        <div className="b-game-card">
        <div className="b-game-card__cover b8-s"></div>
        </div>
      </div>
    </div>
  )
}

export default Music