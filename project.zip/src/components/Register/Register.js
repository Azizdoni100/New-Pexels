import React, { useState } from "react";
import "./register.scss"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFacebook, faGoogle, faLinkedin, faTwitter } from "@fortawesome/free-brands-svg-icons";
import { useNavigate , Link } from "react-router-dom";

const Register = () => {
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    
    const history = useNavigate()
    
    async function register(e) {
      e.preventDefault()
      const data = {
        username: username,
        email: email,
        password: password,
      };
      const response = await fetch("http://81.95.232.205:8007/register/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      console.log(JSON.stringify(data));
      const reg = await response.json()
      console.log(reg)
      localStorage.setItem("token", reg.token);
      history("/")
    }
    return (
    <div className='container-login'>
    <div className="signup">
      <div className="signup-connect">
        <h1 className='h1-title-log'>Create your account</h1>
        <a href="https://www.facebook.com/login" className="btn btn-social btn-facebook"><i className="fawesome"><FontAwesomeIcon className="log-icon" icon={faFacebook} ></FontAwesomeIcon></i>Sign in with Facebook</a>
        <a href="https://twitter.com/login" className="btn btn-social btn-twitter"><i className="fawesome"><FontAwesomeIcon className="log-icon" icon={faTwitter} ></FontAwesomeIcon></i>Sign in with Twitter</a>
        <a href="https://myaccount.google.com/" className="btn btn-social btn-google"><i className="fawesome"><FontAwesomeIcon className="log-icon" icon={faGoogle} ></FontAwesomeIcon></i> Sign in with Google</a>
        <a href="https://www.linkedin.com/login" className="btn btn-social btn-linkedin"><i className="fawesome"><FontAwesomeIcon className="log-icon" icon={faLinkedin} ></FontAwesomeIcon></i> Sign in with Linkedin</a>
      </div>
      <div className="signup-classic">
        <h2 className='h2-title-log'>Or use the classical way</h2>
        <form className="form">
          <fieldset className="username">
            <input type="text" placeholder="username"
              onChange={(e) => setUsername(e.target.value)} />              
          </fieldset>
          <fieldset className="email">
            <input type="email" placeholder="email"
              onChange={(e) => setEmail(e.target.value)}
            />
          </fieldset>
          <fieldset className="password">
            <input lang="eng" type="password" placeholder="password"
              onChange={(e) => setPassword(e.target.value)}
            />
          </fieldset>
          <button className='btn log-btn-btn' type="submit" onClick={register}>Sign Up</button>
        </form>
      </div>
    </div>
  </div>
  )
};

export default Register