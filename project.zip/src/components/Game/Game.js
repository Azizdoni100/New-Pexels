import React from 'react';
import "./game.scss"

const Game = () => {
  return (
    <div>
      <div className='jarallax-img'>
        <div className='jarallax-image-parallax'>
          <h1 className='title-of-image'>UNICON & GAME EXPO</h1>
          <p className='subtitle-of-image'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
          <button className='btn-first-carousel-section'>View Shedule</button>
        </div>
      </div>
    </div>
  )
};

export default Game;
