import React from "react";
import "./number.scss";
import $ from "jquery";

const Number = () => {
  var time = 10,
    cc = 1;
  $(window).scroll(function () {
    $("#counter").each(function () {
      var cPos = $(this).offset().top,
        topWindow = $(window).scrollTop();
      if (cPos < topWindow + 1000) {
        if (cc < 2) {
          $(".number").addClass("viz");
          $("div").each(function () {
            var i = 1,
              num = $(this).data("num"),
              step = (2000 * time) / num,
              that = $(this),
              int = setInterval(function () {
                if (i <= num) {
                  that.html(i);
                } else {
                  cc = cc + 2;
                  clearInterval(int);
                }
                i++;
              }, step);
          });
        }
      }
    });
  });

  return (
    <div className="containerq">
      <div className="grid-container-card">
        <div className="out-parent">
          <img className="twitch-num-img" src="img/twitch.png" alt="" />
          <div className="parent-div--card">
            <div data-num="1300" class="number">
              0
            </div>{" "}
            <span className="plus">+</span>
          </div>
          <h3>TWITCH STREAMS</h3>
        </div>
        <div className="out-parent">
          <img className="twitch-num-img" src="img/youtube.png" alt="" />
          <div className="parent-div--card">
            <div data-num="1100" class="number">
              0
            </div>{" "}
            <span className="plus">+</span>
          </div>
          <h3>YOUTUBE STREAMS</h3>
        </div>
        <div className="out-parent">
          <img className="twitch-num-img" src="img/playstation.png" alt="" />
          <div className="parent-div--card">
            <div data-num="900" class="number">
              0
            </div>{" "}
            <span className="plus">+</span>
          </div>
          <h3>PAST GAMES</h3>
        </div>
        <div className="out-parent">
          <img className="twitch-num-img" src="img/team.png" alt="" />
          <div className="parent-div--card">
            <div data-num="256" class="number">
              0
            </div>{" "}
            <span className="plus">+</span>
          </div>
          <h3>PRO TEAMS</h3>
        </div>
      </div>
      <header>
        <div class="mid">
          <h1>Счетчик чисел при перемотке</h1>
          <h2>&darr;&nbsp;&nbsp; Делайте перемотку вниз &nbsp;&nbsp;&darr;</h2>
        </div>
      </header>
      <article>
        <div class="mid clearfix">
          <div id="counter">
            <div class="bl">
              <div class="text">клиентов</div>
            </div>
            <div class="bl">
              <div class="text">лет гарантии</div>
            </div>
            <div class="bl">
              <div class="text">успешных проектов</div>
            </div>
            <div class="bl">
              <div class="text">человек в команде</div>
            </div>
          </div>
        </div>
      </article>
    </div>
  );
};

export default Number;
