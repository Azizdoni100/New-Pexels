import React, { useState } from "react";
import "./login.scss"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFacebook, faGoogle, faLinkedin, faTwitter } from "@fortawesome/free-brands-svg-icons";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  async function register(e) {
    e.preventDefault()
    const data = {
      username: username,
      password: password,
    };
    const response = await fetch("http://81.95.232.205:8007/login/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
    console.log(JSON.stringify(data));
  }
  return (
    <div className='container-login'>
      <div className="signup">
        <div className="signup-connect bg-connect">

        </div>
        <div className="signup-classic">
          <h2 className='h2-title-log h2-main-title'>we are glad to meet you !!</h2>
          <form className="form">
            <fieldset className="username">
              <input type="text" placeholder="username"
                onChange={(e) => setUsername(e.target.value)} />
            </fieldset>
            <fieldset className="password">
              <input lang="eng" type="password" placeholder="password"
                onChange={(e) => setPassword(e.target.value)}
              />
            </fieldset>
            <button className='log-btn log-btn-button' type="submit" className="btn log-btn-btn" onClick={register}>Sign Up</button>
          </form>
        </div>
      </div>
    </div>
  )
};

export default Login;
