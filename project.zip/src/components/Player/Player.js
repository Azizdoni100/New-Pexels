import "./player.scss";
import { Link } from "react-router-dom";
import * as React from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";

const Player = () => {
  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary,
  }));
  return (
    <div>
      <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={1}>
          <Grid item lg={6} md={6} sm={12}>
            <div className="parent-titles">
              <h1 className="h1-subtitle-of-player-main">
                Game theme for each direction and more.
              </h1>
              <p className="p-subtitle-of-player-main">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis
                ipsum suspendisse ultrices gravida. Risus commodo viverra
                maecenas accumsan lacus vel facilisis.
              </p>
              <button className="learn-more">
                <span className="circle" aria-hidden="true">
                  <span className="icon arrow"></span>
                </span>
                <Link className="a-navbar" to="/about"> <span className="button-text">Read More</span></Link>
              </button>
            </div>
          </Grid>
          <Grid item lg={6} md={6} sm={12}>
            <img className="player-jpg" src="img/player.jpg" alt="" />
          </Grid>
        </Grid>
      </Box>
    </div>
  );
};

export default Player;
