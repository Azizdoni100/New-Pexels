import React, { useContext , useState } from "react";
import { Context } from "../../context";
import "./match.scss";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTwitch } from "@fortawesome/free-brands-svg-icons";



const Match = () => {
  const {game} = useContext(Context);
  const [noOfElements, setnoOfElements] = useState(3)
  const loadMore = () => {
    setnoOfElements(noOfElements + noOfElements)
  }

  const [first, setfirst] = useState(game);
  const slice = first.slice(0, noOfElements)

  function filterElements(category) {
    const mebs = game.filter(function (div) {
      return div.category === category
    })
    setfirst(mebs)
    }

  function FfilterElements(category) {
    setfirst(game, category)
  };

  return (
    <div className="continer">
      <div className="parent-match">
        <div>
          <div className="second-parent-of-match-component">
            <h1>Latest matches</h1>
            <div className="parent-of-buttons">
              <div className="btn-parent">
                <button onClick={() => FfilterElements('ALL')} className="btn-match-component">All</button>
                <span className="span-of-border">/</span>
              </div>
              <div className="btn-parent">
                <button onClick={() => filterElements(3)} className="btn-match-component">CS:GO</button>
                <span className="span-of-border">/</span>
              </div>

              <div className="btn-parent">
                <button onClick={() => filterElements(4)} className="btn-match-component">DOTA 2</button>
                <span className="span-of-border">/</span>
              </div>

              <div className="btn-parent">
                <button onClick={() => filterElements(2)} className="btn-match-component">FORTNITE</button>
                <span className="span-of-border">/</span>
              </div>

              <div className="btn-parent">
                <button onClick={() => filterElements(1)} className="btn-match-component">PUBG</button>
              </div>
            </div>
          </div>
          {slice.map(el => {
            return (
              <div className="parent-of-map">
              <div>
                <div className="parent-main-match-container">
                  <div className="prent-card-parent">
                    <div className="parent-card">
                      <img
                        className="images--main-match-components"
                        src={el.image}
                        alt=""
                      />
                      <h3 className="subtitle--main-match-components">{el.name}</h3>
                      <h3 className="text--main-match-components">{el.achko}</h3>
                    </div>
                    <h2 className="vs-code-title">VS</h2>
                    <div className="parent-card">
                      <img
                        className="images--main-match-components"
                        src={el.image}
                        alt=""
                      />
                      <h3 className="subtitle--main-match-components">{el.name}</h3>
                      <h3 className="text--main-match-components">{el.achko}</h3>
                    </div>
                  </div>
                  <div className="parent-two-titles">
                    <h1 className="h1-text-match">
                      {el.text}
                    </h1>
                    <p className="p-title-match">DECEMBER {el.data} 4:00 PM</p>
                  </div>
                </div>
              </div>
              <div className="card-components-btn-match">
                <button className="btn-twitch-card-match">
                  <FontAwesomeIcon
                    className="twitch-match-icon"
                    icon={faTwitch}
                  ></FontAwesomeIcon>
                  twitch stream
                </button>
              </div>
            </div>
            )
          })}
         
         <div className="parent-load-more-btn">
          <button onClick={() => loadMore()} className="btn-load-more-blog">Load More</button>
        </div>
        </div>
      </div>
    </div>
  );
};

export default Match;

