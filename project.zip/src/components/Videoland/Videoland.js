import React from 'react'
import "./videoland.scss"
import Footer from "../Footer/Footer"
import AOS from 'aos';
import 'aos/dist/aos.css';

const Videoland = () => {
   AOS.init();
  return (
    <div>
        <div className='containers-portfolio'>
               <div data-aos="fade-left" data-aos-duration="1500" className='portfoli-d-flex'>
                   <div>
                   <h2 className='title__main-child'>
                        I`m ready to design your website 
                        and build it with <span className='title-span-fun'>Fun</span>  
                    </h2>
                    <p className='subtitle__main-child'>
                        I`m a beginner web developer. I like to create chic designs for the site. I create websites with fun and pleasure 
                    </p>
                    <button className='btn__main-child'><a className='a-titleparent' href='#parent' onDurationChange={1300}>Check out my work</a></button>
                   </div>
                   <div>
                       <img className='image__main-child' src='https://uploads-ssl.webflow.com/59f4614f2ce6d60001021fcd/5cd93e86cbc64f30d4eb6962_cagdasunal.png'/>
                   </div>
               </div>
               <div id='parent'></div>
               <div data-aos="fade-left" data-aos-duration="1700" className='parent__main__child'>
                      <h2 className='title__main__parents-child'>Byte</h2> 
                      <h2 className='titles__main__parents-child'>The startup used Webflow to reach their target audience in a competitive market</h2>
                      <p className='subtitle__main-childs'>
                      Byte invisible aligner is an innovative product for people who want a better smile. It's a competitive market and Webflow was the perfect solution for their marketing team.
                    </p>
                    <p className='subtitle__main-childs'>
                    First I helped their design process for the marketing website and customer portal. Then I built their responsive website on Webflow.
                    </p>                  
               </div>
               <div data-aos="flip-left" data-aos-duration="1900" className='image__parent-div'>
                   <img className='image__back' src='https://uploads-ssl.webflow.com/5cd3f797ed444018363216ca/5cd48092057bb6241d25c5b7_byte.png' alt=''/>
               </div>
               <div data-aos="flip-up" className='div__parent-second'>
                   <h2 className='title__div-second'>``</h2>
                   <p className='subtitle__div-second'>Çağdaş is very thorough in his plan, email communication and execution. He provided great designs, worked through challenges on what we provided, came up with ideas and solutions to the problems as that brought great encouragement to our team.</p>
                   <img className='image__div-second' src='https://uploads-ssl.webflow.com/5cd3f797ed444018363216ca/5cd3fe96e88ff0b7d2deaa9c_markmcrimmon.png' alt=''/>
                   <p className='title__div-first-info'>Mark McCrimmon</p>
                   <p className='sub-title__main__second'>CTO at <span className='byte__main-title'>Byte</span> </p>
               </div>
               <div data-aos="zoom-in-down" data-aos-duration="2000" className='parent__main__childs'>
                   <div>
                      <h2 className='title__main__parents-childs'>Burt</h2> 
                      <h2 className='titles__main__parents-childs'>The ad tech startup is winning clients from around the world</h2>
                      <p className='subtitle__main-childss'>
                      Burt is a leading ad tech company that operates internationally. Since Webflow is the favorite tool of marketing people, they need my expertise to build their website.
                    </p>
                    <p className='subtitle__main-childss'>
                    After understanding their business goals and priorities, I contributed their design process and built their website on Webflow. Then I provided ongoing support for their regular needs.
                    </p>   
                    </div>
                    <div data-aos="zoom-in-right">
                       <img className='image-parent__main-sectionn' src='https://uploads-ssl.webflow.com/5cd3f797ed444018363216ca/5cd480c363a1fef1d169f1f8_burt.png' alt=''/>    
                    </div>            
               </div>
               <div  data-aos="zoom-out" data-aos-duration="2000" className='div__parent-seconds'>
                   <h2 className='title__div-seconds'>``</h2>
                   <p className='subtitle__div-seconds'>Cağdaş has done great work for us with our new website, including multiple updates and additions. He is quick to answer and has a great pro-active mindset in terms of making sure that we get exactly what we are expecting from a Webflow Expert.</p>
                   <img className='image__div-seconds' src='https://uploads-ssl.webflow.com/5cd3f797ed444018363216ca/5cd3ffc7a5ddc960a214e776_petterfritz.png' alt=''/>
                   <p className='title__div-first-infos'>Petter Fritz</p>
                   <p className='sub-title__main__seconds'>Director Of Business Development at <span className='byte__main-titles'>Burt</span> </p>
               </div>
               <div data-aos="zoom-out-down" data-aos-duration="1700">
                   <div className='main__parent-div'>
                   <div>
                   <h2 className='title__of__parent-div'>Webflow Development</h2>
                   <h2 className='text__of__parent-div'>Your success will begin with a fully functional website on Webflow</h2>
                   <p className='subtitle__main-childss'>
                      Burt is a leading ad tech company that operates internationally. Since Webflow is the favorite tool of marketing people, they need my expertise to build their website.
                    </p>
                    <p className='subtitle__main-childss'>
                    After understanding their business goals and priorities, I contributed their design process and built their website on Webflow. Then I provided ongoing support for their regular needs.
                    </p>  
                    </div>
                    <div>
                    <img className='image__mainparent' src="https://uploads-ssl.webflow.com/5cd3f797ed444018363216ca/5cd4923da5f9ab3f738952ab_webflow-development.png" alt=''/>
                    </div> 
                    </div>
                    <div className='grid__main-section'>
                        <p className='li-title-main__text'>Webflow Development</p>
                        <p className='li-title-main__text'>SEO Audit</p>
                        <p className='li-title-main__text'>Webflow CMS Customization</p>
                        <p className='li-title-main__text'>Bug Fixing   </p>
                        <p className='li-title-main__text'>Sketch to Webflow</p>
                        <p className='li-title-main__text'>Maintenance</p>
                        <p className='li-title-main__text'>Ongoing Support</p>
                        <p className='li-title-main__text'>PSD to Webflow</p>
                    </div>

               </div>
        </div>
        <Footer/>
    </div>
  )
}
export default Videoland