import React from "react";
import Slider from "react-slick";
import "./slidecomp.scss";
import { SRLWrapper } from "simple-react-lightbox";

const SlideComp = () => {
  const settings = {
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 8,
    slidesToScroll: 4,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <div className="parent-of-card-carousel-slide">
      <div className="container-plax">
        <h1 className="text-title-plax">
          Share with <span className="span-plax">#PLAXER</span>
        </h1>
        <p className="title-text-plax">
          Follow me <button className="plaxer-btn">@plaxer</button>
        </p>
      </div>

      <div className="carousel-viewer">
      <SRLWrapper className="carousel-viewer">
      <Slider {...settings}>
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img17.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img2.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img3.jpg"
            alt=""
          />

          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img4.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img5.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img6.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img7.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img8.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img9.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img10.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img11.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img12.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img13.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img14.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img15.jpg"
            alt=""
          />
          <img
            className="images-of-carousel-second"
            src="https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img16.jpg"
            alt=""
          />
      </Slider>
    </SRLWrapper>
      </div>
      <div className="sliders-components"></div>
    </div>
  );
};

export default SlideComp;
