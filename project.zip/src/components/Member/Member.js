import React,{useContext , PureComponent} from 'react'
import { Context } from '../../context'
import MemberPeople from '../MemberPeople/MemberPeople'
import "./member.scss"
import { PieChart, Pie, Cell } from "recharts";

const Member = () => {
    const {people} = useContext(Context)
        const data = [
            { name: "Group A", value: 50 },
            { name: "Group B", value: 30 },
            { name: "Group C", value: 30 }
          ];
          const COLORS = ["#FFA500", "#59B2EF" , "#20B2AA"];
          
          const PieLabel = ({ x, y, cx, percent }) => {
            return (
              <text
                x={x}
                y={y}
                fill="#fff"
                textAnchor={x > cx ? "start" : "end"}
                dominantBaseline="central"
                fontWeight="bold"
              >
                {`${(percent * 100).toFixed(0)}%`}
              </text>
            );
          };
          
    return (
        <div className='container-mem'>
            <div className='parennt-of-member'>
                 <div className='members'>
                     <h3 className='members-text'>Pie Analytic Chart</h3>
                  <PieChart
                     width={350}
                     height={350}
                     margin={{ top: 5, right: 5, bottom: 5, left: 30 }}
                   >
                     <Pie
                       data={data}
                       cx={150}
                       cy={150}
                       innerRadius={80}
                       outerRadius={120}
                       fill="#fff"
                       paddingAngle={2}
                       dataKey="value"
                       labelLine={false}
                       label={PieLabel}
                     >
                       {data.map((entry, index) => (
                         <Cell
                           key={`cell-${index}`}
                           fill={COLORS[index % COLORS.length]}
                           stroke="#fff"
                         />
                       ))}
                     </Pie>
                   </PieChart>
                 </div>
     
                 <div className='the-parent-of-main-section-third'>
                     <h3 className='the-lider-text'>Latest transactions</h3>
                     <div className='parent-of-the-texts'>
                         <h5 className='text-last'>Customer</h5>
                         <h5 className='text-last'>Date</h5>
                         <h5 className='text-last'>Amount</h5>
                         <h5 className='text-last'>Status</h5>
                     </div>
                     <div className='member-children__main'>
                     {people.map(el => {
                         return (
                             <div key={el.id}>
                               <MemberPeople el={el}/>
                                 <div key={el.id} className='elem'>
                                     <div className='image-and-text'>     
                                        <img className='el-image' src={el.image} alt=""/>
                                        <h5 className='elem-title-name'>{el.name}</h5>
                                    </div>
                                    <div>
                                        <h5>{el.date}</h5>
                                    </div>
                                    <div>
                                         <h5>{el.amount}</h5>
                                    </div>
                                    <div>
                                        <button className={`btn-status ${
                                            el.status == 'Approved' ? 'first-btn' : el.status == 'Declined' ? 'second-btn' : "third-btn" 
                                        } first-btn`}>{el.status}</button>
                                    </div>
                                 </div>
                             </div>
                         )
                     })}
                     </div>
                 </div>
            </div>
        </div>
    )
}

export default Member
