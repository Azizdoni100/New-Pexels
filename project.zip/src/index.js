import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router} from 'react-router-dom';
import App from './App';
import { ContextProvider } from "./context";
import SimpleReactLightbox from 'simple-react-lightbox'

ReactDOM.render(
  <ContextProvider>
   <SimpleReactLightbox>
     <Router>
       <App />
     </Router>
  </SimpleReactLightbox>
  </ContextProvider>,
  document.getElementById('root')
);
