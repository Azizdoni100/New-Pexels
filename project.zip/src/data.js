const data = [
  {
    id: 1,
    title: 'Streamlining the Path to Conversion',
    data: "April 22, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img1.jpg',
    category: "PUBG",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text : "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "The Bridge",
    captions: "At the end of last year, Bumblebee em...",
    video: "https://www.youtube.com/watch?v=NHo_x7aGGmU",
  },
  {
    id: 2,
    title: 'Designing for the Web in 2019',
    data: "April 19, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img2.jpg',
    category: "FORTNITE",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "The Last Men",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 3,
    title: 'An Impactful Site is More Than Just Good Design.',
    data: "April 22, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img3.jpg',
    category: "CSGO",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Skyfall",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 4,
    title: 'Driving Engagement Online',
    data: "April 30, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img4.jpg',
    category: "DOTA",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Wasteland",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 5,
    title: 'The Art & Science of Colors and Their Influence on Users',
    data: "April 13, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img6.jpg',
    category: "CSGO",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Found Bride",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 6,
    title: 'SEO Tips for the Contractor and Remodeling Industry ',
    data: "April 13, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img7.jpg',
    category: "PUBG",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Reckoner",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 7,
    title: 'Great Web Design is More Important than Ever Before',
    data: "April 20, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img8.jpg',
    category: "CSGO",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "The Tourist",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 8,
    title: 'Key Factors for Impactful Web Design',
    data: "April 23, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img9.jpg',
    category: "CSGO",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Optimistic",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 9,
    title: 'Power',
    data: "April 9, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img10.jpg',
    category: "DOTA",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Let Down",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 10,
    title: 'Radioactive',
    data: "April 13, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img11.jpg',
    category: "PUBG",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Yellow Flicker Beat ",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 11,
    title: 'Somebody To Love',
    data: "April 22, 2020",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img12.jpg',
    category: "FORTNITE",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Control",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 12,
    title: 'Give In To Me',
    data: "April 3, 2018",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img13.jpg',
    category: "FORTNITE",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Cold Hard Truth",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 13,
    title: 'Take It Out On Me',
    data: "April 13, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img14.jpg',
    category: "DOTA",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Rucksack",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 14,
    title: 'Paradise',
    data: "April 13, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img15.jpg',
    category: "FORTNITE",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Karma Police",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 15,
    title: 'Kills You Slowly',
    data: "April 13, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img16.jpg',
    category: "CSGO",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Videotape",
    captions: "At the end of last year, Bumblebee em..."
  },
  {
    id: 16,
    title: 'Always Remember Us This Way',
    data: "April 13, 2019",
    img:
      'https://promo-theme.com/plaxer/wp-content/uploads/2019/12/img17.jpg',
    category: "FORTNITE",
    subtitle: "From the overarching goal of your website, to the images and videos within it, each element influences how your users perceive and navigate your website. However, even with the most engaging imagery or profound content, if the overall user experience feels dated or unintuitive, then you lower your chances of converting your website visitors online.",
    text: "By providing an engaging user experience, you are more likely to drive conversion and ensure that your website and brand are memorable in the long run. Here are ways to ensure that your corporate website provides a memorable and intuitive user experience for your users online.",
    titled: "“Where as you may meet many sales people, heads of departments, marketing managers and CEO’s as part of your business fast growing with them”",
    subtext: "Before you can dive-in to creating an effective user experience, you need to understand what your user is looking for. Why are they coming to your website, and how can you guide and simplify their experience online?",
    caption: "Desire",
    captions: "At the end of last year, Bumblebee em..."
  },
];

export default data