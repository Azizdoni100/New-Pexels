import * as React from "react";
import { styled } from "@mui/material/styles";
import Carousel from "./components/Carousel/Carousel";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import Card from "./components/Card/Card";
import "./Homes.scss";
import Player from "./components/Player/Player";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Sliders from "./components/Sliders/Sliders";
import Match from "./components/Match/Match";
import Game from "./components/Game/Game";
import Number from "./components/Number/Number";
import SlideComp from "./components/SlideComp/SlideComp";
import Footer from "./components/Footer/Footer";
import Preloader from "./components/Preloader/Preloader"
import Admin from "./components/Admin/Admin"
import {motion} from "framer-motion"

const Homes = () => {
  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary,
  }));
  return (
    <motion.div layout animate={{opacity: 1}} initial={{opacity: 0}} exit={{opacity: 0}}>
    <div id="table">
      <Carousel />
      <div className="parent-home-main">
        <div className="card-container">
          <Box sx={{ flexGrow: 1 }}>
            <div className="card-component">
              <Grid className="card-component" container spacing={6}>
                <Grid item lg={4} md={4} sm={12}>
                  <Card
                    img="img/twitch.png"
                    title="Twitch Streaming"
                    subTitle="New streams every day from our best players."
                  />
                </Grid>
                <Grid item lg={4} md={4} sm={12}>
                  <Card
                    size="285px"
                    img="img/gamepad.png"
                    title="eSport News"
                    subTitle="Get top streams and results from World Cyber Games."
                  />
                </Grid>
                <Grid item lg={4} md={4} sm={12}>
                  <Card
                    img="img/cup.png"
                    title="Game Tournaments"
                    subTitle="Create your own games tournaments and share results."
                  />
                </Grid>
              </Grid>
            </div>
          </Box>
        </div>
      </div>
      <div className="card-container">
        <Player />
      </div>
      <Sliders />
      <Match />
      <Game />
      <Number />
      <SlideComp />
      <Footer />
      <Preloader />
    </div>
    </motion.div>
  );
};

export default Homes;
