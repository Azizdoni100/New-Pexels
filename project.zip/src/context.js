import React, { createContext, useState, useEffect } from "react";
import chartData from "./chartData"
import dates from "./dates"

const Context = createContext();
const ContextProvider = ({ children }) => {
  const [game, setGame] = useState([]);
  const [blog , setBlog] = useState([])
  console.log(game)
  console.log(blog)
  useEffect(() => {
    async function getData() {
      let response = await fetch('http://81.95.232.205:8007/Komandalar/')
      let data = await response.json()
      console.log(data);
      setGame(data)
    }
    getData()
  }, [])
  useEffect(() => {
    async function getBlog() {
      let response = await fetch('http://81.95.232.205:8007/Blog/')
      let blogs = await response.json()
      console.log(blogs); 
      setBlog(blogs)
    }
    getBlog()
  },[])

  const [date] = useState(chartData)
  const [people] = useState(dates)
  let name  = ""
  return (
    <Context.Provider value={{ game, setGame , name , people , date , blog , setBlog}}>{children}</Context.Provider>
  );
};

export { ContextProvider, Context };
