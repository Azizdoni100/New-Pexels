export default [
    {
        result: "win",
        image:
          "https://promo-theme.com/plaxer/wp-content/uploads/2019/12/game-team-logo3-150x150.png",
        name: "CLIKLAV",
        number: "136",
        score: "VS",
        result: "lose",
        image:
          "https://promo-theme.com/plaxer/wp-content/uploads/2019/12/game-team-logo4-150x150.png",
        name: "GERTOS",
        number: "100",
      },
      {
        result: "lose",
        image:
          "https://promo-theme.com/plaxer/wp-content/uploads/2019/12/game-team-logo5-150x150.png",
        name: "GRUV",
        number: "142",
      },
      {
        result: "win",
        image:
          "https://promo-theme.com/plaxer/wp-content/uploads/2019/12/game-team-logo2-150x150.png",
        name: "GDEV",
        number: "130",
      },
      {
        result: "lose",
        image:
          "https://promo-theme.com/plaxer/wp-content/uploads/2019/12/game-team-logo6-150x150.png",
        name: "DRAGONS",
        number: "110",
      },
      {
        result: "win",
        image:
          "https://promo-theme.com/plaxer/wp-content/uploads/2019/12/game-team-logo7-100x100@2x.png",
        name: "COLIN",
        number: "180",
      },
]